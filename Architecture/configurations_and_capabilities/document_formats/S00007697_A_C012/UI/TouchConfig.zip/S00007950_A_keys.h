
//  Copyright (c) Electrolux Group. All rights reserved.
#ifndef __ORL_S00007950_A_KEYS_H
#define __ORL_S00007950_A_KEYS_H

#define orlKey_KEY_root_userInterfaceKey        0x00000000

#endif // __ORL_S00007950_A_KEYS_H
